import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Employee, EpiItem, EpiDelivery, EpiReturn, StockMovement } from '../types';

interface DataContextType {
  employees: Employee[];
  epiItems: EpiItem[];
  deliveries: EpiDelivery[];
  returns: EpiReturn[];
  stockMovements: StockMovement[];
  
  // Employee methods
  addEmployee: (employee: Omit<Employee, 'id' | 'createdAt'>) => void;
  updateEmployee: (id: string, employee: Partial<Employee>) => void;
  deleteEmployee: (id: string) => void;
  
  // EPI Item methods
  addEpiItem: (item: Omit<EpiItem, 'id' | 'createdAt'>) => void;
  updateEpiItem: (id: string, item: Partial<EpiItem>) => void;
  deleteEpiItem: (id: string) => void;
  
  // Delivery methods
  addDelivery: (delivery: Omit<EpiDelivery, 'id' | 'createdAt'>) => void;
  updateDelivery: (id: string, delivery: Partial<EpiDelivery>) => void;
  
  // Return methods
  addReturn: (returnItem: Omit<EpiReturn, 'id' | 'createdAt'>) => void;
  
  // Stock methods
  addStockMovement: (movement: Omit<StockMovement, 'id'>) => void;
  updateStock: (itemId: string, quantity: number, type: 'in' | 'out') => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

interface DataProviderProps {
  children: ReactNode;
}

export const DataProvider: React.FC<DataProviderProps> = ({ children }) => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [epiItems, setEpiItems] = useState<EpiItem[]>([]);
  const [deliveries, setDeliveries] = useState<EpiDelivery[]>([]);
  const [returns, setReturns] = useState<EpiReturn[]>([]);
  const [stockMovements, setStockMovements] = useState<StockMovement[]>([]);

  // Load data from localStorage on mount
  useEffect(() => {
    const loadData = () => {
      const storedEmployees = localStorage.getItem('epi_employees');
      const storedEpiItems = localStorage.getItem('epi_items');
      const storedDeliveries = localStorage.getItem('epi_deliveries');
      const storedReturns = localStorage.getItem('epi_returns');
      const storedMovements = localStorage.getItem('epi_movements');

      if (storedEmployees) setEmployees(JSON.parse(storedEmployees));
      if (storedEpiItems) setEpiItems(JSON.parse(storedEpiItems));
      if (storedDeliveries) setDeliveries(JSON.parse(storedDeliveries));
      if (storedReturns) setReturns(JSON.parse(storedReturns));
      if (storedMovements) setStockMovements(JSON.parse(storedMovements));
    };

    loadData();
  }, []);

  // Save data to localStorage whenever state changes
  useEffect(() => {
    localStorage.setItem('epi_employees', JSON.stringify(employees));
  }, [employees]);

  useEffect(() => {
    localStorage.setItem('epi_items', JSON.stringify(epiItems));
  }, [epiItems]);

  useEffect(() => {
    localStorage.setItem('epi_deliveries', JSON.stringify(deliveries));
  }, [deliveries]);

  useEffect(() => {
    localStorage.setItem('epi_returns', JSON.stringify(returns));
  }, [returns]);

  useEffect(() => {
    localStorage.setItem('epi_movements', JSON.stringify(stockMovements));
  }, [stockMovements]);

  const addEmployee = (employee: Omit<Employee, 'id' | 'createdAt'>) => {
    const newEmployee: Employee = {
      ...employee,
      id: Date.now().toString(),
      createdAt: new Date(),
    };
    setEmployees(prev => [...prev, newEmployee]);
  };

  const updateEmployee = (id: string, employee: Partial<Employee>) => {
    setEmployees(prev =>
      prev.map(emp => (emp.id === id ? { ...emp, ...employee } : emp))
    );
  };

  const deleteEmployee = (id: string) => {
    setEmployees(prev => prev.filter(emp => emp.id !== id));
  };

  const addEpiItem = (item: Omit<EpiItem, 'id' | 'createdAt'>) => {
    const newItem: EpiItem = {
      ...item,
      id: Date.now().toString(),
      createdAt: new Date(),
    };
    setEpiItems(prev => [...prev, newItem]);
  };

  const updateEpiItem = (id: string, item: Partial<EpiItem>) => {
    setEpiItems(prev =>
      prev.map(epi => (epi.id === id ? { ...epi, ...item } : epi))
    );
  };

  const deleteEpiItem = (id: string) => {
    setEpiItems(prev => prev.filter(epi => epi.id !== id));
  };

  const addDelivery = (delivery: Omit<EpiDelivery, 'id' | 'createdAt'>) => {
    const newDelivery: EpiDelivery = {
      ...delivery,
      id: Date.now().toString(),
      createdAt: new Date(),
    };
    setDeliveries(prev => [...prev, newDelivery]);
    
    // Update stock for delivered items
    delivery.items.forEach(item => {
      updateStock(item.itemId, item.quantity, 'out');
    });
  };

  const updateDelivery = (id: string, delivery: Partial<EpiDelivery>) => {
    setDeliveries(prev =>
      prev.map(del => (del.id === id ? { ...del, ...delivery } : del))
    );
  };

  const addReturn = (returnItem: Omit<EpiReturn, 'id' | 'createdAt'>) => {
    const newReturn: EpiReturn = {
      ...returnItem,
      id: Date.now().toString(),
      createdAt: new Date(),
    };
    setReturns(prev => [...prev, newReturn]);
    
    // Update stock for returned items
    updateStock(returnItem.itemId, returnItem.quantity, 'in');
  };

  const addStockMovement = (movement: Omit<StockMovement, 'id'>) => {
    const newMovement: StockMovement = {
      ...movement,
      id: Date.now().toString(),
    };
    setStockMovements(prev => [...prev, newMovement]);
  };

  const updateStock = (itemId: string, quantity: number, type: 'in' | 'out') => {
    setEpiItems(prev =>
      prev.map(item => {
        if (item.id === itemId) {
          const newStock = type === 'in' 
            ? item.stock + quantity 
            : item.stock - quantity;
          return { ...item, stock: Math.max(0, newStock) };
        }
        return item;
      })
    );
  };

  return (
    <DataContext.Provider
      value={{
        employees,
        epiItems,
        deliveries,
        returns,
        stockMovements,
        addEmployee,
        updateEmployee,
        deleteEmployee,
        addEpiItem,
        updateEpiItem,
        deleteEpiItem,
        addDelivery,
        updateDelivery,
        addReturn,
        addStockMovement,
        updateStock,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};