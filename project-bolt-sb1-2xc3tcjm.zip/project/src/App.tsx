import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { DataProvider } from './contexts/DataContext';
import LoginForm from './components/Auth/LoginForm';
import Sidebar from './components/Layout/Sidebar';
import Header from './components/Layout/Header';
import Dashboard from './components/Dashboard/Dashboard';
import EmployeesList from './components/Employees/EmployeesList';
import EpiItemsList from './components/EpiItems/EpiItemsList';
import DeliveriesList from './components/Deliveries/DeliveriesList';
import ReportGenerator from './components/Reports/ReportGenerator';

function AppContent() {
  const { isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  if (!isAuthenticated) {
    return <LoginForm />;
  }

  const getPageTitle = () => {
    switch (activeTab) {
      case 'dashboard': return 'Dashboard';
      case 'employees': return 'Funcionários';
      case 'epi-items': return 'Itens de EPI';
      case 'stock': return 'Controle de Estoque';
      case 'deliveries': return 'Entregas e Devoluções';
      case 'reports': return 'Relatórios';
      case 'settings': return 'Configurações';
      default: return 'Dashboard';
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'employees':
        return <EmployeesList />;
      case 'epi-items':
        return <EpiItemsList />;
      case 'stock':
        return <EpiItemsList />;
      case 'deliveries':
        return <DeliveriesList />;
      case 'reports':
        return <ReportGenerator />;
      case 'settings':
        return (
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Configurações</h3>
            <p className="text-gray-600">Funcionalidades de configuração em desenvolvimento.</p>
          </div>
        );
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isCollapsed={sidebarCollapsed}
        setIsCollapsed={setSidebarCollapsed}
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title={getPageTitle()} />
        
        <main className="flex-1 overflow-x-hidden overflow-y-auto p-6">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <AppContent />
      </DataProvider>
    </AuthProvider>
  );
}

export default App;