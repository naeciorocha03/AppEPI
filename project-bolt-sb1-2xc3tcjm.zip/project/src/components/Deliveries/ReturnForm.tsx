import React, { useState } from 'react';
import { X, Package, Calendar, FileText, AlertTriangle } from 'lucide-react';
import { useData } from '../../contexts/DataContext';
import { useAuth } from '../../contexts/AuthContext';

interface ReturnFormProps {
  isOpen: boolean;
  onClose: () => void;
  deliveryId: string;
  onSave: () => void;
}

const ReturnForm: React.FC<ReturnFormProps> = ({ isOpen, onClose, deliveryId, onSave }) => {
  const { deliveries, epiItems, addReturn, updateDelivery } = useData();
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    itemId: '',
    quantity: 1,
    returnDate: new Date().toISOString().split('T')[0],
    reason: '',
    condition: 'good' as const,
    notes: '',
  });

  const delivery = deliveries.find(d => d.id === deliveryId);
  const availableItems = delivery?.items || [];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.itemId) {
      alert('Por favor, selecione um item para devolução');
      return;
    }

    addReturn({
      deliveryId,
      itemId: formData.itemId,
      quantity: formData.quantity,
      returnDate: new Date(formData.returnDate),
      reason: formData.reason,
      condition: formData.condition,
      userId: user?.id || '',
      notes: formData.notes,
    });

    // Update delivery status
    const deliveryItem = delivery?.items.find(item => item.itemId === formData.itemId);
    if (deliveryItem && deliveryItem.quantity === formData.quantity) {
      // If all items of this type are returned, check if delivery is fully returned
      const allReturned = delivery?.items.every(item => {
        // This would need more complex logic to track partial returns
        return item.itemId === formData.itemId;
      });
      
      updateDelivery(deliveryId, {
        status: allReturned ? 'returned' : 'partially_returned'
      });
    } else {
      updateDelivery(deliveryId, { status: 'partially_returned' });
    }

    onSave();
    onClose();
    setFormData({
      itemId: '',
      quantity: 1,
      returnDate: new Date().toISOString().split('T')[0],
      reason: '',
      condition: 'good',
      notes: '',
    });
  };

  const getItemName = (itemId: string) => {
    const item = epiItems.find(epi => epi.id === itemId);
    return item?.name || 'Item não encontrado';
  };

  const getMaxQuantity = (itemId: string) => {
    const deliveryItem = availableItems.find(item => item.itemId === itemId);
    return deliveryItem?.quantity || 1;
  };

  if (!isOpen || !delivery) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md mx-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-800">Devolução de EPI</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Package className="h-4 w-4 inline mr-1" />
              Item a Devolver *
            </label>
            <select
              required
              value={formData.itemId}
              onChange={(e) => {
                setFormData(prev => ({ 
                  ...prev, 
                  itemId: e.target.value,
                  quantity: 1
                }));
              }}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Selecione um item</option>
              {availableItems.map(item => (
                <option key={item.itemId} value={item.itemId}>
                  {getItemName(item.itemId)} (Qtd: {item.quantity})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Quantidade *
            </label>
            <input
              type="number"
              required
              min="1"
              max={getMaxQuantity(formData.itemId)}
              value={formData.quantity}
              onChange={(e) => setFormData(prev => ({ ...prev, quantity: Number(e.target.value) }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Calendar className="h-4 w-4 inline mr-1" />
              Data da Devolução *
            </label>
            <input
              type="date"
              required
              value={formData.returnDate}
              onChange={(e) => setFormData(prev => ({ ...prev, returnDate: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Motivo da Devolução *
            </label>
            <select
              required
              value={formData.reason}
              onChange={(e) => setFormData(prev => ({ ...prev, reason: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Selecione o motivo</option>
              <option value="damaged">Danificado</option>
              <option value="expired">Vencido</option>
              <option value="wrong_size">Tamanho incorreto</option>
              <option value="no_longer_needed">Não precisa mais</option>
              <option value="replacement">Substituição</option>
              <option value="other">Outro</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <AlertTriangle className="h-4 w-4 inline mr-1" />
              Condição do Item *
            </label>
            <select
              required
              value={formData.condition}
              onChange={(e) => setFormData(prev => ({ ...prev, condition: e.target.value as any }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="good">Bom estado</option>
              <option value="damaged">Danificado</option>
              <option value="expired">Vencido</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <FileText className="h-4 w-4 inline mr-1" />
              Observações
            </label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Observações sobre a devolução..."
            />
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
            >
              Registrar Devolução
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ReturnForm;