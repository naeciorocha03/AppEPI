import React, { useState } from 'react';
import { Plus, Search, Filter, User, Package, Calendar, FileText, RotateCcw } from 'lucide-react';
import { useData } from '../../contexts/DataContext';
import DeliveryForm from './DeliveryForm';
import ReturnForm from './ReturnForm';

const DeliveriesList: React.FC = () => {
  const { deliveries, employees, epiItems } = useData();
  const [isDeliveryFormOpen, setIsDeliveryFormOpen] = useState(false);
  const [isReturnFormOpen, setIsReturnFormOpen] = useState(false);
  const [selectedDelivery, setSelectedDelivery] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const filteredDeliveries = deliveries.filter(delivery => {
    const employee = employees.find(emp => emp.id === delivery.employeeId);
    const matchesSearch = employee?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         employee?.registration.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || delivery.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const sortedDeliveries = filteredDeliveries.sort((a, b) => 
    new Date(b.deliveryDate).getTime() - new Date(a.deliveryDate).getTime()
  );

  const getEmployeeName = (employeeId: string) => {
    const employee = employees.find(emp => emp.id === employeeId);
    return employee?.name || 'Funcionário não encontrado';
  };

  const getItemName = (itemId: string) => {
    const item = epiItems.find(epi => epi.id === itemId);
    return item?.name || 'Item não encontrado';
  };

  const handleReturn = (deliveryId: string) => {
    setSelectedDelivery(deliveryId);
    setIsReturnFormOpen(true);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered':
        return 'bg-green-100 text-green-800';
      case 'returned':
        return 'bg-gray-100 text-gray-800';
      case 'partially_returned':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'delivered':
        return 'Entregue';
      case 'returned':
        return 'Devolvido';
      case 'partially_returned':
        return 'Parcialmente Devolvido';
      default:
        return 'Desconhecido';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">Entregas de EPI</h2>
        <button
          onClick={() => setIsDeliveryFormOpen(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
        >
          <Plus className="h-4 w-4" />
          <span>Nova Entrega</span>
        </button>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar por funcionário..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">Todos os Status</option>
              <option value="delivered">Entregues</option>
              <option value="returned">Devolvidos</option>
              <option value="partially_returned">Parcialmente Devolvidos</option>
            </select>
          </div>
        </div>

        <div className="space-y-4">
          {sortedDeliveries.map((delivery) => (
            <div key={delivery.id} className="border border-gray-200 rounded-lg p-4">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="font-semibold text-gray-800 flex items-center">
                    <User className="h-4 w-4 mr-2" />
                    {getEmployeeName(delivery.employeeId)}
                  </h3>
                  <p className="text-sm text-gray-600 flex items-center mt-1">
                    <Calendar className="h-3 w-3 mr-1" />
                    {new Date(delivery.deliveryDate).toLocaleDateString('pt-BR')}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(delivery.status)}`}>
                    {getStatusText(delivery.status)}
                  </span>
                  {delivery.status === 'delivered' && (
                    <button
                      onClick={() => handleReturn(delivery.id)}
                      className="bg-orange-600 text-white px-3 py-1 rounded-lg hover:bg-orange-700 transition-colors flex items-center space-x-1"
                    >
                      <RotateCcw className="h-3 w-3" />
                      <span>Devolver</span>
                    </button>
                  )}
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-3">
                <h4 className="font-medium text-gray-700 mb-2 flex items-center">
                  <Package className="h-4 w-4 mr-2" />
                  Itens Entregues
                </h4>
                <div className="space-y-1">
                  {delivery.items.map((item, index) => (
                    <div key={index} className="flex justify-between items-center text-sm">
                      <span className="text-gray-700">{getItemName(item.itemId)}</span>
                      <span className="text-gray-600">Qtd: {item.quantity}</span>
                    </div>
                  ))}
                </div>
              </div>

              {delivery.notes && (
                <div className="mt-3 p-3 bg-blue-50 rounded-lg">
                  <p className="text-sm text-blue-800 flex items-start">
                    <FileText className="h-4 w-4 mr-2 mt-0.5 flex-shrink-0" />
                    {delivery.notes}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>

        {sortedDeliveries.length === 0 && (
          <div className="text-center py-8">
            <p className="text-gray-500">Nenhuma entrega encontrada</p>
          </div>
        )}
      </div>

      <DeliveryForm
        isOpen={isDeliveryFormOpen}
        onClose={() => setIsDeliveryFormOpen(false)}
        onSave={() => {}}
      />

      <ReturnForm
        isOpen={isReturnFormOpen}
        onClose={() => setIsReturnFormOpen(false)}
        deliveryId={selectedDelivery}
        onSave={() => {}}
      />
    </div>
  );
};

export default DeliveriesList;