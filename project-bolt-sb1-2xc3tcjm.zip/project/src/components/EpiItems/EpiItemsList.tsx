import React, { useState } from 'react';
import { Plus, Edit, Trash2, Search, Filter, AlertTriangle, Clock } from 'lucide-react';
import { useData } from '../../contexts/DataContext';
import EpiItemForm from './EpiItemForm';
import { EpiItem } from '../../types';

const EpiItemsList: React.FC = () => {
  const { epiItems, deleteEpiItem } = useData();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<EpiItem | undefined>();
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');

  const filteredItems = epiItems.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.category.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = categoryFilter === 'all' || item.category === categoryFilter;
    
    return matchesSearch && matchesCategory;
  });

  const categories = [...new Set(epiItems.map(item => item.category))];

  const handleEdit = (item: EpiItem) => {
    setSelectedItem(item);
    setIsFormOpen(true);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Tem certeza que deseja excluir este item?')) {
      deleteEpiItem(id);
    }
  };

  const handleFormClose = () => {
    setIsFormOpen(false);
    setSelectedItem(undefined);
  };

  const getStockStatus = (item: EpiItem) => {
    if (item.stock <= item.minStock) {
      return { color: 'text-red-600', bg: 'bg-red-100', icon: AlertTriangle };
    }
    return { color: 'text-green-600', bg: 'bg-green-100', icon: null };
  };

  const getExpiryStatus = (item: EpiItem) => {
    if (!item.expirationDate) return null;
    
    const expiryDate = new Date(item.expirationDate);
    const today = new Date();
    const diffTime = expiryDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) {
      return { color: 'text-red-600', bg: 'bg-red-100', text: 'Vencido' };
    }
    if (diffDays <= 30) {
      return { color: 'text-orange-600', bg: 'bg-orange-100', text: `${diffDays} dias` };
    }
    return { color: 'text-green-600', bg: 'bg-green-100', text: 'OK' };
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">Itens de EPI</h2>
        <button
          onClick={() => setIsFormOpen(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
        >
          <Plus className="h-4 w-4" />
          <span>Novo Item</span>
        </button>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar itens..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">Todas as Categorias</option>
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-medium text-gray-700">Nome</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Código</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Categoria</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Tamanho</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Estoque</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Validade</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filteredItems.map((item) => {
                const stockStatus = getStockStatus(item);
                const expiryStatus = getExpiryStatus(item);
                const StockIcon = stockStatus.icon;
                
                return (
                  <tr key={item.id} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4 font-medium text-gray-800">{item.name}</td>
                    <td className="py-3 px-4 text-gray-600">{item.code}</td>
                    <td className="py-3 px-4 text-gray-600">{item.category}</td>
                    <td className="py-3 px-4 text-gray-600">{item.size}</td>
                    <td className="py-3 px-4">
                      <div className="flex items-center space-x-1">
                        {StockIcon && <StockIcon className="h-4 w-4 text-red-600" />}
                        <span className={`font-medium ${stockStatus.color}`}>
                          {item.stock}
                        </span>
                        <span className="text-gray-500">/ {item.minStock}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      {expiryStatus ? (
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${expiryStatus.bg} ${expiryStatus.color}`}>
                          {expiryStatus.text}
                        </span>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleEdit(item)}
                          className="text-blue-600 hover:text-blue-800 transition-colors"
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(item.id)}
                          className="text-red-600 hover:text-red-800 transition-colors"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredItems.length === 0 && (
          <div className="text-center py-8">
            <p className="text-gray-500">Nenhum item encontrado</p>
          </div>
        )}
      </div>

      <EpiItemForm
        isOpen={isFormOpen}
        onClose={handleFormClose}
        item={selectedItem}
        onSave={() => {}}
      />
    </div>
  );
};

export default EpiItemsList;