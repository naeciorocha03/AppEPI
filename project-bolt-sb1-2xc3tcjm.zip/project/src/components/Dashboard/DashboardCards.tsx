import React from 'react';
import { Users, Shield, Package, AlertTriangle, TrendingUp, Clock } from 'lucide-react';
import { useData } from '../../contexts/DataContext';

const DashboardCards: React.FC = () => {
  const { employees, epiItems, deliveries } = useData();

  const activeEmployees = employees.filter(emp => emp.status === 'active').length;
  const totalItems = epiItems.length;
  const totalDeliveries = deliveries.length;
  const lowStockItems = epiItems.filter(item => item.stock <= item.minStock).length;
  const expiredItems = epiItems.filter(item => 
    item.expirationDate && new Date(item.expirationDate) < new Date()
  ).length;
  const nearExpiryItems = epiItems.filter(item => {
    if (!item.expirationDate) return false;
    const expiryDate = new Date(item.expirationDate);
    const today = new Date();
    const diffTime = expiryDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 30 && diffDays > 0;
  }).length;

  const cards = [
    {
      title: 'Funcionários Ativos',
      value: activeEmployees,
      icon: Users,
      color: 'bg-blue-500',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-600'
    },
    {
      title: 'Itens de EPI',
      value: totalItems,
      icon: Shield,
      color: 'bg-green-500',
      bgColor: 'bg-green-50',
      textColor: 'text-green-600'
    },
    {
      title: 'Entregas Realizadas',
      value: totalDeliveries,
      icon: Package,
      color: 'bg-purple-500',
      bgColor: 'bg-purple-50',
      textColor: 'text-purple-600'
    },
    {
      title: 'Estoque Baixo',
      value: lowStockItems,
      icon: AlertTriangle,
      color: 'bg-yellow-500',
      bgColor: 'bg-yellow-50',
      textColor: 'text-yellow-600'
    },
    {
      title: 'Itens Vencidos',
      value: expiredItems,
      icon: TrendingUp,
      color: 'bg-red-500',
      bgColor: 'bg-red-50',
      textColor: 'text-red-600'
    },
    {
      title: 'Próximos ao Vencimento',
      value: nearExpiryItems,
      icon: Clock,
      color: 'bg-orange-500',
      bgColor: 'bg-orange-50',
      textColor: 'text-orange-600'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {cards.map((card, index) => {
        const Icon = card.icon;
        return (
          <div key={index} className={`${card.bgColor} p-6 rounded-lg border border-gray-200`}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{card.title}</p>
                <p className={`text-3xl font-bold ${card.textColor}`}>{card.value}</p>
              </div>
              <div className={`${card.color} p-3 rounded-full`}>
                <Icon className="h-6 w-6 text-white" />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default DashboardCards;