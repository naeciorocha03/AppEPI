import React from 'react';
import { AlertTriangle, Clock, Package } from 'lucide-react';
import { useData } from '../../contexts/DataContext';

const StockAlerts: React.FC = () => {
  const { epiItems } = useData();

  const lowStockItems = epiItems.filter(item => item.stock <= item.minStock);
  const expiredItems = epiItems.filter(item => 
    item.expirationDate && new Date(item.expirationDate) < new Date()
  );
  const nearExpiryItems = epiItems.filter(item => {
    if (!item.expirationDate) return false;
    const expiryDate = new Date(item.expirationDate);
    const today = new Date();
    const diffTime = expiryDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 30 && diffDays > 0;
  });

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Alertas de Estoque</h3>
      
      <div className="space-y-4">
        {/* Low Stock */}
        {lowStockItems.length > 0 && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <AlertTriangle className="h-5 w-5 text-yellow-600" />
              <h4 className="font-medium text-yellow-800">Estoque Baixo ({lowStockItems.length})</h4>
            </div>
            <div className="space-y-2">
              {lowStockItems.slice(0, 3).map((item) => (
                <div key={item.id} className="flex justify-between items-center text-sm">
                  <span className="text-yellow-700">{item.name}</span>
                  <span className="text-yellow-600 font-medium">{item.stock} unidades</span>
                </div>
              ))}
              {lowStockItems.length > 3 && (
                <p className="text-xs text-yellow-600">+{lowStockItems.length - 3} mais itens</p>
              )}
            </div>
          </div>
        )}

        {/* Expired Items */}
        {expiredItems.length > 0 && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <Package className="h-5 w-5 text-red-600" />
              <h4 className="font-medium text-red-800">Itens Vencidos ({expiredItems.length})</h4>
            </div>
            <div className="space-y-2">
              {expiredItems.slice(0, 3).map((item) => (
                <div key={item.id} className="flex justify-between items-center text-sm">
                  <span className="text-red-700">{item.name}</span>
                  <span className="text-red-600 font-medium">
                    {item.expirationDate && new Date(item.expirationDate).toLocaleDateString('pt-BR')}
                  </span>
                </div>
              ))}
              {expiredItems.length > 3 && (
                <p className="text-xs text-red-600">+{expiredItems.length - 3} mais itens</p>
              )}
            </div>
          </div>
        )}

        {/* Near Expiry */}
        {nearExpiryItems.length > 0 && (
          <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <Clock className="h-5 w-5 text-orange-600" />
              <h4 className="font-medium text-orange-800">Próximos ao Vencimento ({nearExpiryItems.length})</h4>
            </div>
            <div className="space-y-2">
              {nearExpiryItems.slice(0, 3).map((item) => (
                <div key={item.id} className="flex justify-between items-center text-sm">
                  <span className="text-orange-700">{item.name}</span>
                  <span className="text-orange-600 font-medium">
                    {item.expirationDate && new Date(item.expirationDate).toLocaleDateString('pt-BR')}
                  </span>
                </div>
              ))}
              {nearExpiryItems.length > 3 && (
                <p className="text-xs text-orange-600">+{nearExpiryItems.length - 3} mais itens</p>
              )}
            </div>
          </div>
        )}

        {lowStockItems.length === 0 && expiredItems.length === 0 && nearExpiryItems.length === 0 && (
          <div className="text-center py-8">
            <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">Nenhum alerta de estoque</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default StockAlerts;