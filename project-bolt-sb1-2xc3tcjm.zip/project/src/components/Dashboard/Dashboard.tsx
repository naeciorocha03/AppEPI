import React from 'react';
import DashboardCards from './DashboardCards';
import RecentActivity from './RecentActivity';
import StockAlerts from './StockAlerts';

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-6">
      <DashboardCards />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <RecentActivity />
        <StockAlerts />
      </div>
    </div>
  );
};

export default Dashboard;