import React from 'react';
import { Calendar, User, Package, ArrowRight } from 'lucide-react';
import { useData } from '../../contexts/DataContext';

const RecentActivity: React.FC = () => {
  const { deliveries, employees, epiItems } = useData();

  const recentDeliveries = deliveries
    .sort((a, b) => new Date(b.deliveryDate).getTime() - new Date(a.deliveryDate).getTime())
    .slice(0, 5);

  const getEmployeeName = (employeeId: string) => {
    const employee = employees.find(emp => emp.id === employeeId);
    return employee?.name || 'Funcionário não encontrado';
  };

  const getItemName = (itemId: string) => {
    const item = epiItems.find(epi => epi.id === itemId);
    return item?.name || 'Item não encontrado';
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Atividades Recentes</h3>
      
      <div className="space-y-4">
        {recentDeliveries.length === 0 ? (
          <p className="text-gray-500 text-center py-8">Nenhuma atividade recente</p>
        ) : (
          recentDeliveries.map((delivery) => (
            <div key={delivery.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="bg-blue-100 p-2 rounded-full">
                  <Package className="h-4 w-4 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium text-gray-800">
                    Entrega para {getEmployeeName(delivery.employeeId)}
                  </p>
                  <p className="text-sm text-gray-600">
                    {delivery.items.length} item(s) entregue(s)
                  </p>
                  <div className="flex items-center space-x-2 mt-1">
                    <Calendar className="h-3 w-3 text-gray-400" />
                    <span className="text-xs text-gray-500">
                      {new Date(delivery.deliveryDate).toLocaleDateString('pt-BR')}
                    </span>
                  </div>
                </div>
              </div>
              <ArrowRight className="h-4 w-4 text-gray-400" />
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default RecentActivity;