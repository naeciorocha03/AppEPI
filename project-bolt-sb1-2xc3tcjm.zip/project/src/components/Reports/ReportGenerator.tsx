import React, { useState } from 'react';
import { FileText, Download, Calendar, Users, Package, DollarSign, Filter } from 'lucide-react';
import { useData } from '../../contexts/DataContext';

const ReportGenerator: React.FC = () => {
  const { employees, epiItems, deliveries, returns } = useData();
  const [reportType, setReportType] = useState('monthly');
  const [filters, setFilters] = useState({
    startDate: '',
    endDate: '',
    employeeId: '',
    itemId: '',
    sector: '',
  });

  const generateReport = () => {
    let data: any = {};
    
    switch (reportType) {
      case 'monthly':
        data = generateMonthlyReport();
        break;
      case 'individual':
        data = generateIndividualReport();
        break;
      case 'stock':
        data = generateStockReport();
        break;
      case 'cost':
        data = generateCostReport();
        break;
    }

    // Create a simple text report
    const reportContent = formatReport(data);
    downloadReport(reportContent);
  };

  const generateMonthlyReport = () => {
    const filteredDeliveries = deliveries.filter(delivery => {
      const deliveryDate = new Date(delivery.deliveryDate);
      const startDate = filters.startDate ? new Date(filters.startDate) : new Date(0);
      const endDate = filters.endDate ? new Date(filters.endDate) : new Date();
      
      return deliveryDate >= startDate && deliveryDate <= endDate;
    });

    const itemCount: { [key: string]: number } = {};
    const sectorCount: { [key: string]: number } = {};

    filteredDeliveries.forEach(delivery => {
      const employee = employees.find(emp => emp.id === delivery.employeeId);
      if (employee) {
        sectorCount[employee.sector] = (sectorCount[employee.sector] || 0) + 1;
      }

      delivery.items.forEach(item => {
        const epiItem = epiItems.find(epi => epi.id === item.itemId);
        if (epiItem) {
          itemCount[epiItem.name] = (itemCount[epiItem.name] || 0) + item.quantity;
        }
      });
    });

    return {
      totalDeliveries: filteredDeliveries.length,
      itemCount,
      sectorCount,
      period: `${filters.startDate || 'Início'} até ${filters.endDate || 'Hoje'}`,
    };
  };

  const generateIndividualReport = () => {
    if (!filters.employeeId) return {};

    const employee = employees.find(emp => emp.id === filters.employeeId);
    const employeeDeliveries = deliveries.filter(d => d.employeeId === filters.employeeId);
    const employeeReturns = returns.filter(r => 
      employeeDeliveries.some(d => d.id === r.deliveryId)
    );

    return {
      employee,
      deliveries: employeeDeliveries,
      returns: employeeReturns,
      totalDeliveries: employeeDeliveries.length,
      totalReturns: employeeReturns.length,
    };
  };

  const generateStockReport = () => {
    let filteredItems = epiItems;

    if (filters.itemId) {
      filteredItems = filteredItems.filter(item => item.id === filters.itemId);
    }

    const lowStockItems = filteredItems.filter(item => item.stock <= item.minStock);
    const expiredItems = filteredItems.filter(item => 
      item.expirationDate && new Date(item.expirationDate) < new Date()
    );

    return {
      totalItems: filteredItems.length,
      lowStockItems,
      expiredItems,
      totalStock: filteredItems.reduce((sum, item) => sum + item.stock, 0),
      totalValue: filteredItems.reduce((sum, item) => sum + (item.stock * item.unitCost), 0),
    };
  };

  const generateCostReport = () => {
    const filteredDeliveries = deliveries.filter(delivery => {
      const deliveryDate = new Date(delivery.deliveryDate);
      const startDate = filters.startDate ? new Date(filters.startDate) : new Date(0);
      const endDate = filters.endDate ? new Date(filters.endDate) : new Date();
      
      return deliveryDate >= startDate && deliveryDate <= endDate;
    });

    let totalCost = 0;
    const costByItem: { [key: string]: number } = {};

    filteredDeliveries.forEach(delivery => {
      delivery.items.forEach(item => {
        const cost = item.quantity * item.unitCost;
        totalCost += cost;
        
        const epiItem = epiItems.find(epi => epi.id === item.itemId);
        if (epiItem) {
          costByItem[epiItem.name] = (costByItem[epiItem.name] || 0) + cost;
        }
      });
    });

    return {
      totalCost,
      costByItem,
      period: `${filters.startDate || 'Início'} até ${filters.endDate || 'Hoje'}`,
    };
  };

  const formatReport = (data: any) => {
    let content = `RELATÓRIO DE EPIs\n`;
    content += `Gerado em: ${new Date().toLocaleString('pt-BR')}\n`;
    content += `Tipo: ${getReportTypeName(reportType)}\n\n`;

    switch (reportType) {
      case 'monthly':
        content += `RELATÓRIO MENSAL\n`;
        content += `Período: ${data.period}\n`;
        content += `Total de Entregas: ${data.totalDeliveries}\n\n`;
        
        content += `ITENS MAIS ENTREGUES:\n`;
        Object.entries(data.itemCount).forEach(([item, count]) => {
          content += `- ${item}: ${count} unidades\n`;
        });
        
        content += `\nENTREGAS POR SETOR:\n`;
        Object.entries(data.sectorCount).forEach(([sector, count]) => {
          content += `- ${sector}: ${count} entregas\n`;
        });
        break;

      case 'stock':
        content += `RELATÓRIO DE ESTOQUE\n`;
        content += `Total de Itens: ${data.totalItems}\n`;
        content += `Estoque Total: ${data.totalStock} unidades\n`;
        content += `Valor Total: R$ ${data.totalValue.toFixed(2)}\n\n`;
        
        if (data.lowStockItems.length > 0) {
          content += `ITENS COM ESTOQUE BAIXO:\n`;
          data.lowStockItems.forEach((item: any) => {
            content += `- ${item.name}: ${item.stock} unidades (mín: ${item.minStock})\n`;
          });
        }
        
        if (data.expiredItems.length > 0) {
          content += `\nITENS VENCIDOS:\n`;
          data.expiredItems.forEach((item: any) => {
            content += `- ${item.name}: ${new Date(item.expirationDate).toLocaleDateString('pt-BR')}\n`;
          });
        }
        break;

      case 'cost':
        content += `RELATÓRIO DE CUSTOS\n`;
        content += `Período: ${data.period}\n`;
        content += `Custo Total: R$ ${data.totalCost.toFixed(2)}\n\n`;
        
        content += `CUSTO POR ITEM:\n`;
        Object.entries(data.costByItem).forEach(([item, cost]) => {
          content += `- ${item}: R$ ${(cost as number).toFixed(2)}\n`;
        });
        break;
    }

    return content;
  };

  const downloadReport = (content: string) => {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `relatorio_epi_${reportType}_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  const getReportTypeName = (type: string) => {
    switch (type) {
      case 'monthly': return 'Relatório Mensal';
      case 'individual': return 'Relatório Individual';
      case 'stock': return 'Relatório de Estoque';
      case 'cost': return 'Relatório de Custos';
      default: return 'Relatório';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-2">
        <FileText className="h-6 w-6 text-blue-600" />
        <h2 className="text-2xl font-bold text-gray-800">Relatórios</h2>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Tipo de Relatório
            </label>
            <select
              value={reportType}
              onChange={(e) => setReportType(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="monthly">Relatório Mensal</option>
              <option value="individual">Relatório Individual</option>
              <option value="stock">Relatório de Estoque</option>
              <option value="cost">Relatório de Custos</option>
            </select>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-800 flex items-center">
              <Filter className="h-5 w-5 mr-2" />
              Filtros
            </h3>

            {(reportType === 'monthly' || reportType === 'cost') && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Data Inicial
                  </label>
                  <input
                    type="date"
                    value={filters.startDate}
                    onChange={(e) => setFilters(prev => ({ ...prev, startDate: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Data Final
                  </label>
                  <input
                    type="date"
                    value={filters.endDate}
                    onChange={(e) => setFilters(prev => ({ ...prev, endDate: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            )}

            {reportType === 'individual' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Funcionário
                </label>
                <select
                  value={filters.employeeId}
                  onChange={(e) => setFilters(prev => ({ ...prev, employeeId: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Selecione um funcionário</option>
                  {employees.map(emp => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} - {emp.registration}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {reportType === 'stock' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Item Específico (opcional)
                </label>
                <select
                  value={filters.itemId}
                  onChange={(e) => setFilters(prev => ({ ...prev, itemId: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Todos os itens</option>
                  {epiItems.map(item => (
                    <option key={item.id} value={item.id}>
                      {item.name} - {item.code}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button
            onClick={generateReport}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
          >
            <Download className="h-4 w-4" />
            <span>Gerar Relatório</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-blue-600">Total de Entregas</p>
              <p className="text-2xl font-bold text-blue-800">{deliveries.length}</p>
            </div>
            <Users className="h-8 w-8 text-blue-600" />
          </div>
        </div>

        <div className="bg-green-50 p-4 rounded-lg border border-green-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-green-600">Itens Cadastrados</p>
              <p className="text-2xl font-bold text-green-800">{epiItems.length}</p>
            </div>
            <Package className="h-8 w-8 text-green-600" />
          </div>
        </div>

        <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-purple-600">Devoluções</p>
              <p className="text-2xl font-bold text-purple-800">{returns.length}</p>
            </div>
            <FileText className="h-8 w-8 text-purple-600" />
          </div>
        </div>

        <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-orange-600">Valor Total</p>
              <p className="text-2xl font-bold text-orange-800">
                R$ {epiItems.reduce((sum, item) => sum + (item.stock * item.unitCost), 0).toFixed(2)}
              </p>
            </div>
            <DollarSign className="h-8 w-8 text-orange-600" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReportGenerator;