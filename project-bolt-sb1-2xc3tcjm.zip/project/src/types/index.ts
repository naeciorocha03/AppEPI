export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'stockist' | 'safety';
  createdAt: Date;
}

export interface Employee {
  id: string;
  name: string;
  registration: string;
  cpf?: string;
  sector: string;
  position: string;
  admissionDate: Date;
  status: 'active' | 'inactive';
  createdAt: Date;
}

export interface EpiItem {
  id: string;
  name: string;
  code: string;
  category: string;
  size: string;
  description: string;
  expirationDate?: Date;
  stock: number;
  minStock: number;
  supplier: string;
  supplierCnpj: string;
  unitCost: number;
  createdAt: Date;
}

export interface StockMovement {
  id: string;
  itemId: string;
  type: 'in' | 'out';
  quantity: number;
  date: Date;
  reason: string;
  userId: string;
  employeeId?: string;
  notes?: string;
}

export interface EpiDelivery {
  id: string;
  employeeId: string;
  items: {
    itemId: string;
    quantity: number;
    unitCost: number;
  }[];
  deliveryDate: Date;
  notes?: string;
  proofDocument?: string;
  userId: string;
  status: 'delivered' | 'returned' | 'partially_returned';
  createdAt: Date;
}

export interface EpiReturn {
  id: string;
  deliveryId: string;
  itemId: string;
  quantity: number;
  returnDate: Date;
  reason: string;
  condition: 'good' | 'damaged' | 'expired';
  userId: string;
  notes?: string;
  createdAt: Date;
}

export interface Report {
  id: string;
  type: 'monthly' | 'individual' | 'stock' | 'cost';
  parameters: any;
  generatedAt: Date;
  userId: string;
  data: any;
}